package project16;

public class StairCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
